const {
  cmd
} = require("../command");
cmd({
  'pattern': 'wa',
  'alias': ["wamw", "whois"],
  'desc': "Display a contact's number in three formats (requires reply to a message). (Owner only)",
  'category': "contact",
  'react': '🎴',
  'filename': __filename,
  'use': ".wa (reply to a message)"
}, async (_0x20b1a9, _0x38b3af, _0x3a86e9, {
  from: _0x4a33a,
  sender: _0x2ab1a7,
  isOwner: _0x999d56,
  reply: _0x5cb474
}) => {
  try {
    if (!_0x999d56) {
      return _0x5cb474("*_❌ You are not authorized to use this command._*");
    }
    if (!_0x3a86e9.quoted) {
      return _0x5cb474("*_⚠️ Please reply to a message to get that contact's number._*");
    }
    const _0x416dfc = _0x3a86e9.quoted.sender;
    if (!_0x416dfc) {
      return _0x5cb474("❌ Unable to retrieve the contact's number.");
    }
    const _0x90267e = _0x416dfc.split('@')[0];
    const _0x37f014 = _0x90267e.startsWith('+') ? _0x90267e : '+' + _0x90267e;
    const _0x17095f = "https://wa.me/" + _0x90267e;
    const _0x409455 = _0x90267e + "@s.whatsapp.net";
    const _0x35b54e = "*📞CONTACT NUMBER FORMATS :*\n\n" + ("*INTERNATIONAL FORMAT :* " + _0x37f014 + "\n") + ("*LINK :* " + _0x17095f + "\n") + ("*JID :* " + _0x409455 + "\n\n") + "*ᴀᴡᴀɪs ᴍᴅ*";
    return _0x5cb474(_0x35b54e);
  } catch (_0x4a5331) {
    console.error("Error in wa command:", _0x4a5331);
    return _0x5cb474("❌ An error occurred: " + _0x4a5331.message);
  }
});


const {
  sleep
} = require("../lib/functions");
cmd({
  'pattern': "rcolor",
  'react': "🎨",
  'alias': ["randomcolour"],
  'desc': "Generate a random color with name and code.",
  'category': "utility",
  'filename': __filename
}, async (_0x8560d0, _0x167905, _0x44f4dc, {
  reply: _0x526f68
}) => {
  try {
    const _0x4bcd29 = ["Red", "Green", "Blue", "Yellow", "Orange", "Purple", "Pink", "Brown", "Black", "White", "Gray", "Cyan", "Magenta", "Violet", "Indigo", "Teal", "Lavender", "Turquoise"];
    const _0x44ef3a = '#' + Math.floor(Math.random() * 16777215).toString(16);
    const _0x140f13 = _0x4bcd29[Math.floor(Math.random() * _0x4bcd29.length)];
    _0x526f68(" *`AWAIS-MD RANDOM COLOUR:`* \n\nColour Name: " + _0x140f13 + "\nCode: " + _0x44ef3a);
  } catch (_0x1116ab) {
    console.error("Error in .randomcolor command:", _0x1116ab);
    _0x526f68("❌ An error occurred while generating the random color.");
  }
});
cmd({
  'pattern': "binary",
  'react': "🤹‍♂️",
  'desc': "Convert text into binary format.",
  'category': "utility",
  'filename': __filename
}, async (_0x52557c, _0x1fd52f, _0x37d889, {
  args: _0xdf02f1,
  reply: _0x3292b7
}) => {
  try {
    if (!_0xdf02f1.length) {
      return _0x3292b7("❌ Please provide the text to convert to binary.");
    }
    const _0x4eb2dc = _0xdf02f1.join(" ");
    const _0x52f4fd = _0x4eb2dc.split('').map(_0xc3d6c1 => {
      return ("00000000" + _0xc3d6c1.charCodeAt(0).toString(2)).slice(-8);
    }).join(" ");
    _0x3292b7(" *`AWAIS-MD BINARY REPRESENTATION:`* \n\n" + _0x52f4fd);
  } catch (_0x5e3d86) {
    console.error("Error in .binary command:", _0x5e3d86);
    _0x3292b7("❌ An error occurred while converting to binary.");
  }
});
cmd({
  'pattern': "dbinary",
  'react': '🧩',
  'desc': "Decode binary string into text.",
  'category': "utility",
  'filename': __filename
}, async (_0x54c726, _0x14282e, _0x2584f2, {
  args: _0x23b9d9,
  reply: _0x2f1c72
}) => {
  try {
    if (!_0x23b9d9.length) {
      return _0x2f1c72("❌ Please provide the binary string to decode.");
    }
    const _0x293f92 = _0x23b9d9.join(" ");
    const _0x51228e = _0x293f92.split(" ").map(_0x3fc862 => {
      return String.fromCharCode(parseInt(_0x3fc862, 2));
    }).join('');
    _0x2f1c72("*`AWAIS-MD KERM DECODED TEXT:`* \n\n" + _0x51228e);
  } catch (_0x2c1976) {
    console.error("Error in .binarydecode command:", _0x2c1976);
    _0x2f1c72("❌ An error occurred while decoding the binary string.");
  }
});
cmd({
  'pattern': "encode",
  'react': '🧩',
  'desc': "Encode text into Base64 format.",
  'category': "utility",
  'filename': __filename
}, async (_0xded51d, _0x1763d1, _0x3b64ea, {
  args: _0x3aa463,
  reply: _0x141f35
}) => {
  try {
    if (!_0x3aa463.length) {
      return _0x141f35("❌ Please provide the text to encode into Base64.");
    }
    const _0x16da54 = _0x3aa463.join(" ");
    const _0x7a83dc = Buffer.from(_0x16da54).toString("base64");
    _0x141f35(" *`Encoded Base64 Text:`* \n\n" + _0x7a83dc);
  } catch (_0x5be071) {
    console.error("Error in .encode command:", _0x5be071);
    _0x141f35("❌ An error occurred while encoding the text into Base64.");
  }
});
cmd({
  'pattern': "decode",
  'react': "🤹‍♂️",
  'desc': "Decode Base64 encoded text.",
  'category': "utility",
  'filename': __filename
}, async (_0x5eecf4, _0x22c65f, _0x40f6fd, {
  args: _0xc6a7c3,
  reply: _0x3c637f
}) => {
  try {
    if (!_0xc6a7c3.length) {
      return _0x3c637f("❌ Please provide the Base64 encoded text to decode.");
    }
    const _0x2cb9bd = _0xc6a7c3.join(" ");
    const _0xff48ea = Buffer.from(_0x2cb9bd, "base64").toString("utf-8");
    _0x3c637f("*`Kerm Decoded Text:`* \n\n" + _0xff48ea);
  } catch (_0x585090) {
    console.error("Error in .decode command:", _0x585090);
    _0x3c637f("❌ An error occurred while decoding the Base64 text.");
  }
});
cmd({
  'pattern': "urlencode",
  'desc': "Encode text into URL encoding.",
  'category': "utility",
  'filename': __filename
}, async (_0x1027ba, _0x15e60d, _0x418496, {
  args: _0x209208,
  reply: _0x7740d3
}) => {
  try {
    if (!_0x209208.length) {
      return _0x7740d3("❌ Please provide the text to encode into URL encoding.");
    }
    const _0x5160e8 = _0x209208.join(" ");
    const _0x516aac = encodeURIComponent(_0x5160e8);
    _0x7740d3(" *AWAIS-MD ENCODED URL TEXT:* \n" + _0x516aac);
  } catch (_0x247bf9) {
    console.error("Error in .urlencode command:", _0x247bf9);
    _0x7740d3("❌ An error occurred while encoding the text.");
  }
});
cmd({
  'pattern': "urldecode",
  'desc': "Decode URL encoded text.",
  'category': "utility",
  'filename': __filename
}, async (_0x31922c, _0x33f61a, _0x4b2c3d, {
  args: _0x218e07,
  reply: _0x5baef3
}) => {
  try {
    if (!_0x218e07.length) {
      return _0x5baef3("❌ Please provide the URL encoded text to decode.");
    }
    const _0x2b884a = _0x218e07.join(" ");
    const _0x4b6fe4 = decodeURIComponent(_0x2b884a);
    _0x5baef3("🔓 *Decoded Text:* \n" + _0x4b6fe4);
  } catch (_0x10fcbe) {
    console.error("Error in .urldecode command:", _0x10fcbe);
    _0x5baef3("❌ An error occurred while decoding the URL encoded text.");
  }
});
cmd({
  'pattern': "roll",
  'desc': "Roll a dice (1-6).",
  'category': "fun",
  'filename': __filename
}, async (_0x1b4c41, _0x499af6, _0x29afb8, {
  reply: _0xb24ee0
}) => {
  try {
    const _0x23e051 = Math.floor(Math.random() * 6) + 1;
    _0xb24ee0("🎲 You rolled: *" + _0x23e051 + '*');
  } catch (_0x2cb63d) {
    console.error("Error in .roll command:", _0x2cb63d);
    _0xb24ee0("❌ An error occurred while rolling the dice.");
  }
});
cmd({
  'pattern': "coinflip",
  'desc': "Flip a coin and get Heads or Tails.",
  'category': "fun",
  'filename': __filename
}, async (_0x17e55b, _0x244be1, _0x3f8ff3, {
  reply: _0xb04fca
}) => {
  try {
    const _0x3838b5 = Math.random() < 0.5 ? "Heads" : "Tails";
    _0xb04fca("🪙 Coin Flip Result: *" + _0x3838b5 + '*');
  } catch (_0xe040de) {
    console.error("Error in .coinflip command:", _0xe040de);
    _0xb04fca("❌ An error occurred while flipping the coin.");
  }
});
cmd({
  'pattern': "flip",
  'desc': "Flip the text you provide.",
  'category': "fun",
  'filename': __filename
}, async (_0x2c2550, _0x2f8c60, _0x407842, {
  args: _0x40b6cf,
  reply: _0x19b1cc
}) => {
  try {
    if (!_0x40b6cf.length) {
      return _0x19b1cc("❌ Please provide the text to flip.");
    }
    const _0x2bb3ca = _0x40b6cf.join(" ").split('').reverse().join('');
    _0x19b1cc("🔄 Flipped Text: *" + _0x2bb3ca + '*');
  } catch (_0x131b65) {
    console.error("Error in .flip command:", _0x131b65);
    _0x19b1cc("❌ An error occurred while flipping the text.");
  }
});
cmd({
  'pattern': "pick",
  'desc': "Pick between two choices.",
  'category': "fun",
  'filename': __filename
}, async (_0x50d6a4, _0x2d50d7, _0x2320f2, {
  args: _0x484ada,
  reply: _0xd6f175
}) => {
  try {
    if (_0x484ada.length < 2) {
      return _0xd6f175("❌ Please provide two choices to pick from. Example: `.pick Ice Cream, Pizza`");
    }
    const _0x901f8f = _0x484ada.join(" ").split(',')[Math.floor(Math.random() * 2)].trim();
    _0xd6f175("🎉 Bot picks: *" + _0x901f8f + '*');
  } catch (_0x97ac36) {
    console.error("Error in .pick command:", _0x97ac36);
    _0xd6f175("❌ An error occurred while processing your request.");
  }
});
cmd({
  'pattern': "timenow",
  'desc': "Check the current local time.",
  'category': "utility",
  'filename': __filename
}, async (_0x1ce536, _0x1c9ef2, _0xe6bd87, {
  reply: _0x179317
}) => {
  try {
    const _0x466373 = new Date();
    const _0x2d3186 = _0x466373.toLocaleTimeString("en-US", {
      'hour': "2-digit",
      'minute': "2-digit",
      'second': "2-digit",
      'hour12': true,
      'timeZone': "Asia/Pakistan"
    });
    _0x179317("🕒 Current Local Time in Zimbabwe6: " + _0x2d3186);
  } catch (_0xefc4dd) {
    console.error("Error in .timenow command:", _0xefc4dd);
    _0x179317("❌ An error occurred. Please try again later.");
  }
});
cmd({
  'pattern': "date",
  'desc': "Check the current date.",
  'category': "utility",
  'filename': __filename
}, async (_0x282767, _0x13e39b, _0x252449, {
  reply: _0x908e01
}) => {
  try {
    const _0x3e2e98 = new Date();
    const _0x5f0c8a = _0x3e2e98.toLocaleDateString("en-US", {
      'weekday': "long",
      'year': "numeric",
      'month': "long",
      'day': "numeric"
    });
    _0x908e01("📅 Current Date: " + _0x5f0c8a);
  } catch (_0x3abf26) {
    console.error("Error in .date command:", _0x3abf26);
    _0x908e01("❌ An error occurred. Please try again later.");
  }
});
cmd({
  'pattern': "shapar",
  'desc': "Send shapar ASCII art with mentions.",
  'category': "fun",
  'filename': __filename
}, async (_0x5be15e, _0x5e15bd, _0x3b3c93, {
  from: _0x543aff,
  isGroup: _0x42b860,
  reply: _0x450ecb
}) => {
  try {
    if (!_0x42b860) {
      return _0x450ecb("This command can only be used in groups.");
    }
    const _0x43ccb0 = _0x3b3c93.message.extendedTextMessage?.["contextInfo"]?.["mentionedJid"]?.[0];
    if (!_0x43ccb0) {
      return _0x450ecb("Please mention a user to send the ASCII art to.");
    }
    const _0x3ece44 = "😂 @" + _0x43ccb0.split('@')[0] + "!\n😂 that for you:\n\n" + "\n          _______\n       .-'       '-.\n      /           /|\n     /           / |\n    /___________/  |\n    |   _______ |  |\n    |  |  \\ \\  ||  |\n    |  |   \\ \\ ||  |\n    |  |____\\ \\||  |\n    |  '._  _.'||  |\n    |    .' '.  ||  |\n    |   '.___.' ||  |\n    |___________||  |\n    '------------'  |\n     \\_____________\\|\n";
    await _0x5be15e.sendMessage(_0x543aff, {
      'text': _0x3ece44,
      'mentions': [_0x43ccb0]
    }, {
      'quoted': _0x3b3c93
    });
  } catch (_0x4513e0) {
    console.error("Error in .shapar command:", _0x4513e0);
    _0x450ecb("An error occurred while processing the command. Please try again.");
  }
});
cmd({
  'pattern': "rate",
  'desc': "Rate someone out of 10.",
  'category': "fun",
  'filename': __filename
}, async (_0x83bec5, _0x2e7643, _0x51b664, {
  from: _0xff4365,
  isGroup: _0x348d09,
  reply: _0x14349e
}) => {
  try {
    if (!_0x348d09) {
      return _0x14349e("This command can only be used in groups.");
    }
    const _0x230d05 = _0x51b664.message.extendedTextMessage?.["contextInfo"]?.["mentionedJid"]?.[0];
    if (!_0x230d05) {
      return _0x14349e("Please mention someone to rate.");
    }
    const _0x12c6bb = Math.floor(Math.random() * 10) + 1;
    const _0x61193f = '@' + _0x230d05.split('@')[0] + " is rated " + _0x12c6bb + "/10.";
    await _0x83bec5.sendMessage(_0xff4365, {
      'text': _0x61193f,
      'mentions': [_0x230d05]
    }, {
      'quoted': _0x51b664
    });
  } catch (_0x47b998) {
    console.error("Error in .rate command:", _0x47b998);
    _0x14349e("An error occurred. Please try again.");
  }
});

cmd({
  'pattern': "calculate",
  'alias': ["calc"],
  'desc': "Evaluate a mathematical expression.",
  'category': "utility",
  'filename': __filename
}, async (_0x1a58b0, _0xbef67f, _0x245942, {
  args: _0x31f2a4,
  reply: _0x8da92a
}) => {
  try {
    if (!_0x31f2a4[0]) {
      return _0x8da92a("✳️ Use this command like:\n *Example:* .calculate 5+3*2");
    }
    const _0x316725 = _0x31f2a4.join(" ").trim();
    if (!/^[0-9+\-*/().\s]+$/.test(_0x316725)) {
      return _0x8da92a("❎ Invalid expression. Only numbers and +, -, *, /, ( ) are allowed.");
    }
    let _0x428880;
    try {
      _0x428880 = eval(_0x316725);
    } catch (_0x2b7662) {
      return _0x8da92a("❎ Error in calculation. Please check your expression.");
    }
    _0x8da92a("✅ Result of \"" + _0x316725 + "\" is: " + _0x428880);
  } catch (_0x2e437e) {
    console.error(_0x2e437e);
    _0x8da92a("❎ An error occurred while processing your request.");
  }
});
let activeGames = {};
cmd({
  'pattern': "numbergame",
  'react': '🎲',
  'desc': "Start a number guessing game.",
  'category': "utility",
  'use': ".numbergame",
  'filename': __filename
}, async (_0x220881, _0x3f5670, _0x504c37, {
  from: _0x4adfb4,
  reply: _0x53103e,
  isGroup: _0x33a1ae,
  sender: _0x5dd2ac
}) => {
  try {
    if (activeGames[_0x4adfb4]) {
      return _0x53103e("❌ A game is already in progress! Use `.endgame` to stop it.");
    }
    const _0x404ecf = Math.floor(Math.random() * 100) + 1;
    activeGames[_0x4adfb4] = {
      'targetNumber': _0x404ecf,
      'attempts': {}
    };
    await _0x53103e("🎉 *Number Game Started!* 🎉\n\nI have chosen a number between 1 and 100.\nGuess the number by typing it in the chat!");
  } catch (_0x4e976b) {
    console.error(_0x4e976b);
    _0x53103e("❌ An error occurred while starting the game.");
  }
});
cmd({
  'pattern': "guess",
  'react': '🤔',
  'desc': "Make a guess in the number game.",
  'category': "utility",
  'use': ".guess <number>",
  'filename': __filename
}, async (_0x1046e7, _0x4cb2ca, _0x5a06e0, {
  from: _0xcbdba3,
  reply: _0xc94579,
  q: _0xede12a,
  sender: _0x36a324
}) => {
  try {
    const _0x30abb9 = activeGames[_0xcbdba3];
    if (!_0x30abb9) {
      return _0xc94579("❌ No game is currently in progress. Start one with `.numbergame`.");
    }
    const _0x52509b = parseInt(_0xede12a);
    if (isNaN(_0x52509b)) {
      return _0xc94579("❌ Please provide a valid number.");
    }
    if (_0x52509b === _0x30abb9.targetNumber) {
      delete activeGames[_0xcbdba3];
      return await _0xc94579("🎉 *Congratulations!* 🎉\n\nThe correct number was *" + _0x52509b + "*.\nGame over!");
    }
    if (!_0x30abb9.attempts[_0x36a324]) {
      _0x30abb9.attempts[_0x36a324] = 0;
    }
    _0x30abb9.attempts[_0x36a324]++;
    return _0x52509b > _0x30abb9.targetNumber ? _0xc94579("📉 *Too high!* Try again.") : _0xc94579("📈 *Too low!* Try again.");
  } catch (_0x5068b0) {
    console.error(_0x5068b0);
    _0xc94579("❌ An error occurred while processing your guess.");
  }
});
cmd({
  'pattern': "endgame",
  'react': '❌',
  'desc': "End the current number game.",
  'category': "utility",
  'use': ".endgame",
  'filename': __filename
}, async (_0xf3d1e9, _0x667a9, _0x4cd773, {
  from: _0xfa4d62,
  reply: _0x4fe171
}) => {
  try {
    if (!activeGames[_0xfa4d62]) {
      return _0x4fe171("❌ No game is currently in progress.");
    }
    delete activeGames[_0xfa4d62];
    _0x4fe171("❌ *Game ended.*");
  } catch (_0x406b35) {
    console.error(_0x406b35);
    _0x4fe171("❌ An error occurred while ending the game.");
  }
});
 
 //*CREATED BY /AWAIS XD*
